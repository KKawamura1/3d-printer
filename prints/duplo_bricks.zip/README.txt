DUPLO-size prototypes, mm units. Import at 100% scale, NOT 200%.
2x4 body: 63.8 x 31.8 x 19.2 mm.
2x2 body: 31.8 x 31.8 x 19.2 mm.
Both total height: 23.7 mm. Hollow top studs.
Clearance: 0 (uncalibrated nominal candidate).
Fit and holding force against genuine DUPLO have NOT been physically validated.
Start with the smaller 2x2. Use the slicer for your actual printer/material.
